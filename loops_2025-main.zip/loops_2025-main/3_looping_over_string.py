# Example Practice:
# Ask the user for a word.
# Use a for loop to print each letter on a new line.

# Challenge:
# Count how many vowels are in the word.
